<!DOCTYPE html>
<html lang="en">


<head>
    <?php echo $__env->make('roles.Layout.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?></title>
</head>


<body id="kt_app_body" class="app-default">
    <div class="d-flex flex-column flex-root app-root" id="kt_app_root">
        <div class="app-page flex-column flex-column-fluid" id="kt_app_page">
            <!-- HEADER MULAI DI SINI -->
            <div id="kt_app_header" class="app-header">
                <?php echo $__env->make('roles.Layout.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- HEADER SELESAI -->
            <div class="app-wrapper d-flex flex-row flex-row-fluid" id="kt_app_wrapper">
                <?php echo $__env->make('roles.Layout.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="app-main flex-column flex-row-fluid" id="kt_app_main">
                    <div class="d-flex flex-column flex-column-fluid">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>

                    <!--begin::Footer-->
                    <?php echo $__env->make('roles.Layout.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!--end::Footer-->
                </div>
            </div>
        </div>
    </div>
    </div>
    <?php echo $__env->make('roles.Layout.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\internal\resources\views/roles/Layout/partials/app.blade.php ENDPATH**/ ?>