<header id="header" class="header d-flex align-items-center sticky-top">
    <div class="container-fluid container-xl position-relative d-flex align-items-center">

        <a href="<?php echo e(url('/')); ?>" class="logo d-flex align-items-center me-auto">
            <!-- Uncomment the line below if you also wish to use an image logo -->
            <!-- <img src="<?php echo e(asset('frontend/assets/img/logo.png')); ?>" alt=""> -->
            <h1 class="sitename"><?php echo $__env->yieldContent('site_title', 'INTERNAL JAYA NIAGA SEMESTA'); ?></h1>
        </a>

        <nav id="navmenu" class="navmenu">
            <ul>
                <li><a href="<?php echo e(route('permintaan.create')); ?>"
                        class="<?php echo e(request()->routeIs('permintaan.create') ? 'active' : ''); ?>">Pencarian Barang</a></li>
                <li><a href="<?php echo e(route('perdin.create')); ?>"
                        class="<?php echo e(request()->routeIs('perdin.create') ? 'active' : ''); ?>">Formulir Pengajuan
                        Perdin</a></li>
            </ul>
            <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
        </nav>

        <?php if(auth()->guard()->check()): ?>
            <form method="POST" action="<?php echo e(route('logout')); ?>" class="d-inline ms-3">
                <?php echo csrf_field(); ?>
                <span class="me-2 text-white"><?php echo e(auth()->user()->name); ?></span>
                <button class="btn btn-sm btn-outline-light">Logout</button>
            </form>
        <?php else: ?>
            <a class="btn-getstarted" href="<?php echo e(url('/login')); ?>">Login</a>
        <?php endif; ?>

    </div>
</header>
<?php /**PATH C:\xampp\htdocs\internal\resources\views/partials/header.blade.php ENDPATH**/ ?>