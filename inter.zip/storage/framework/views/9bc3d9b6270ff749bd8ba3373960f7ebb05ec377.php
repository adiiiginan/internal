
<?php $__env->startSection('title', 'Finance - Approved Perdin List'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>Approved Perdin Submissions</span>
            </div>
            <div class="card-body">
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>

                <?php if($perdins->isEmpty()): ?>
                    <div class="alert alert-info">No approved perdin records found.</div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered mb-0">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Nama</th>
                                    <th>Jabatan</th>
                                    <th>Tujuan</th>
                                    <th>Total</th>
                                    <th>Advance</th>
                                    <th>Expense</th>
                                    <th>Status</th>
                                    <th>Created At</th>
                                    <th class="text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $perdins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i + 1); ?></td>
                                        <td><?php echo e($p->nama); ?></td>
                                        <td><?php echo e($p->jabatan); ?></td>
                                        <td><?php echo e($p->tujuan); ?></td>
                                        <td><?php echo e(number_format($p->total, 2)); ?></td>
                                        <td><?php echo e(number_format($p->advance, 2)); ?></td>
                                        <td><?php echo e(number_format($p->expense, 2)); ?></td>
                                        <td>
                                            <span class="badge bg-success">Approved</span>
                                        </td>
                                        <td><?php echo e($p->created_at); ?></td>
                                        <td class="text-center">
                                            <a href="<?php echo e(route('roles.finance.pdf', $p->id)); ?>"
                                                class="btn btn-sm btn-secondary" target="_blank">PDF</a>
                                            <form action="<?php echo e(route('roles.finance.destroy', $p->id)); ?>" method="POST"
                                                style="display:inline"
                                                onsubmit="return confirm('Are you sure you want to delete this perdin?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="btn btn-sm btn-danger" type="submit">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('roles.Layout.partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\internal\resources\views/roles/finance/approved.blade.php ENDPATH**/ ?>