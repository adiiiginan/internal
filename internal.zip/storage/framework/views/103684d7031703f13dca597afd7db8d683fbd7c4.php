<script src="<?php echo e(asset('backend/assets/plugins/global/plugins.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/js/scripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/plugins/custom/datatables/datatables.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/plugins/custom/vis-timeline/vis-timeline.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/js/widgets.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/js/custom/widgets.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/js/custom/apps/chat/chat.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/js/custom/utilities/modals/upgrade-plan.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/js/custom/utilities/modals/create-campaign.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/js/custom/utilities/modals/users-search.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
<?php /**PATH C:\xampp\htdocs\internal\resources\views/roles/Layout/partials/scripts.blade.php ENDPATH**/ ?>