<!DOCTYPE html>
<html>

<head>
    <title>Daftar Permintaan Barang</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            border: 1px solid #000;
            padding: 6px;
            text-align: left;
            font-size: 12px;
        }

        th {
            background: #f2f2f2;
        }

        img {
            object-fit: cover;
            border-radius: 6px;
        }
    </style>
</head>

<body>
    <h2 style="text-align: center;">Daftar Permintaan Barang</h2>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Divisi</th>
                <th>Jenis Permintaan</th>
                <th>Deskripsi</th>
                <th>Jumlah</th>
                <th>Annual Ussage</th>
                <th>Tanggal</th>
                <th>Supplier</th>
                <th>Customer</th>
                <th>Deadline</th>
                <th>Gambar</th> <!-- ✅ Tambahkan kolom gambar -->
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1</td>
                <td><?php echo e($permintaan->nama); ?></td>
                <td><?php echo e($permintaan->divisi); ?></td>
                <td><?php echo e($permintaan->jenis_permintaan); ?></td>
                <td><?php echo e($permintaan->deskripsi); ?></td>
                <td><?php echo e($permintaan->qty); ?></td>
                <td><?php echo e($permintaan->use); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($permintaan->tanggal)->format('d-m-Y')); ?></td>
                <td><?php echo e($permintaan->supplier); ?></td>
                <td><?php echo e($permintaan->customer); ?></td>
                <td><?php echo e($permintaan->etd); ?></td>
                <td>
                    <?php if($permintaan->gambar): ?>
                        <img src="<?php echo e(public_path('backend/assets/media/gambar/' . $permintaan->gambar)); ?>"
                            width="80">
                    <?php else: ?>
                        -
                    <?php endif; ?>
                </td>
            </tr>
        </tbody>
    </table>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\internal\resources\views/roles/admin/pdf.blade.php ENDPATH**/ ?>