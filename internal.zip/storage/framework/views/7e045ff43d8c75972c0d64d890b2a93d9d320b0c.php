

<?php $__env->startSection('title', 'Daftar Permintaan Barang'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex flex-column flex-column-fluid">
        <!--begin::Toolbar-->
        <div id="kt_app_toolbar" class="app-toolbar pt-6 pb-2">
            <div id="kt_app_toolbar_container" class="app-container container-fluid d-flex align-items-stretch">
                <div class="app-toolbar-wrapper d-flex flex-stack flex-wrap gap-4 w-100">
                    <div class="page-title d-flex flex-column justify-content-center gap-1 me-3">
                        <h1 class="page-heading d-flex flex-column justify-content-center text-gray-900 fw-bold fs-3 m-0">
                            Daftar Permintaan Barang</h1>
                        <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0">
                            <li class="breadcrumb-item text-muted">
                                <a href="<?php echo e(route('dashboard')); ?>" class="text-muted text-hover-primary">Home</a>
                            </li>
                            <li class="breadcrumb-item">
                                <span class="bullet bg-gray-500 w-5px h-2px"></span>
                            </li>
                            <li class="breadcrumb-item text-muted">Permintaan</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!--end::Toolbar-->

        <!--begin::Content-->
        <div id="kt_app_content" class="app-content flex-column-fluid">
            <div id="kt_app_content_container" class="app-container container-fluid">
                <div class="card card-flush">
                    <div class="card-header align-items-center py-5 gap-2 gap-md-5">
                        <div class="card-title">
                            <div class="d-flex align-items-center position-relative my-1">
                                <i class="ki-outline ki-magnifier fs-3 position-absolute ms-4"></i>
                                <input type="text" id="searchInput" class="form-control form-control-solid w-250px ps-12"
                                    placeholder="Cari Permintaan" />
                            </div>
                        </div>
                        <div class="card-toolbar d-flex justify-content-end gap-5">
                            <a href="<?php echo e(route('admin.permintaan.exportExcel')); ?>" class="btn btn-light-primary">
                                <i class="ki-outline ki-exit-up fs-2"></i>Export Excel
                            </a>
                        </div>
                    </div>

                    <div class="card-body pt-0">
                        <div class="table-responsive">
                            <table class="table align-middle table-row-dashed fs-6 gy-5" id="permintaanTable">
                                <thead>
                                    <tr class="text-start text-gray-500 fw-bold fs-7 text-uppercase gs-0">
                                        <th>No</th>
                                        <th>Gambar</th>
                                        <th>Nama</th>
                                        <th>Divisi</th>
                                        <th>Jenis Permintaan</th>
                                        <th>Jumlah</th>
                                        <th>Tanggal</th>
                                        <th>Deskripsi</th>
                                        <th>Supplier</th>
                                        <th>Customer</th>
                                        <th>Deadline</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody class="fw-semibold text-gray-600">
                                    <?php $__currentLoopData = $permintaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td>
                                                <?php if($item->gambar): ?>
                                                    <img src="<?php echo e(asset('backend/assets/media/gambar/' . $item->gambar)); ?>"
                                                        alt="gambar" width="60" height="60"
                                                        style="object-fit: cover; border-radius: 8px; cursor:pointer;"
                                                        data-bs-toggle="modal"
                                                        data-bs-target="#gambarModal<?php echo e($item->id); ?>">

                                                    <!-- Modal -->
                                                    <div class="modal fade" id="gambarModal<?php echo e($item->id); ?>"
                                                        tabindex="-1" aria-labelledby="gambarModalLabel<?php echo e($item->id); ?>"
                                                        aria-hidden="true">
                                                        <div class="modal-dialog modal-dialog-centered modal-lg">
                                                            <div class="modal-content bg-transparent border-0 shadow-none">
                                                                <div class="modal-body text-center">
                                                                    <img src="<?php echo e(asset('backend/assets/media/gambar/' . $item->gambar)); ?>"
                                                                        class="img-fluid rounded shadow" alt="gambar besar">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php else: ?>
                                                    <span class="text-muted">Tidak ada</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($item->nama); ?></td>
                                            <td><?php echo e($item->divisi); ?></td>
                                            <td><?php echo e($item->jenis_permintaan); ?></td>
                                            <td><?php echo e($item->qty); ?></td>
                                            <td><?php echo e(\Carbon\Carbon::parse($item->tanggal)->format('d-m-Y')); ?></td>
                                            <td><?php echo e($item->deskripsi); ?></td>
                                            <td><?php echo e($item->supplier); ?></td>
                                            <td><?php echo e($item->customer); ?></td>
                                            <td><?php echo e($item->etd); ?></td>
                                            <td>
                                                <?php if($item->status == 'pending'): ?>
                                                    <span class="badge badge-light-warning">Pending</span>
                                                <?php elseif($item->status == 'on progress'): ?>
                                                    <span class="badge badge-light-info">On Progress</span>
                                                <?php elseif($item->status == 'done'): ?>
                                                    <span class="badge badge-light-success">Done</span>
                                                <?php else: ?>
                                                    <span class="badge badge-light-secondary"><?php echo e($item->status); ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <th>
                                                <div class="card-toolbar d-flex gap-2">
                                                    <a href="<?php echo e(route('admin.permintaan.pdf', $item->id)); ?>"
                                                        class="btn btn-sm btn-light btn-active-light-primary">
                                                        <i class="ki-outline ki-exit-up fs-4"></i> PDF
                                                    </a>
                                                    <button class="btn btn-sm btn-light btn-active-light-warning"
                                                        data-bs-toggle="modal"
                                                        data-bs-target="#statusModal<?php echo e($item->id); ?>">
                                                        <i class="fas fa-edit"></i> Status
                                                    </button>
                                                    <form action="<?php echo e(route('admin.permintaan.destroy', $item->id)); ?>"
                                                        method="POST" class="d-inline">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('delete'); ?>
                                                        <button class="btn btn-sm btn-light btn-active-light-danger"
                                                            onclick="return confirm('Apakah Anda yakin ingin menghapus?')">
                                                            <i class="fas fa-trash"></i> Delete
                                                        </button>
                                                    </form>
                                                </div>
                                            </th>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end::Content-->
    </div>

    <!-- Status Update Modals -->
    <?php $__currentLoopData = $permintaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="statusModal<?php echo e($item->id); ?>" tabindex="-1"
            aria-labelledby="statusModalLabel<?php echo e($item->id); ?>" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="statusModalLabel<?php echo e($item->id); ?>">Update Status Permintaan</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form action="<?php echo e(route('admin.permintaan.updateStatus', $item->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="status<?php echo e($item->id); ?>" class="form-label">Status</label>
                                <select class="form-select" id="status<?php echo e($item->id); ?>" name="status" required>
                                    <option value="">Pilih Status</option>
                                    <option value="pending" <?php echo e($item->status == 'pending' ? 'selected' : ''); ?>>Pending
                                    </option>
                                    <option value="on progress" <?php echo e($item->status == 'on progress' ? 'selected' : ''); ?>>On
                                        Progress</option>
                                    <option value="done" <?php echo e($item->status == 'done' ? 'selected' : ''); ?>>Done</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-primary">Update Status</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.dataTables.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.5.0/js/dataTables.responsive.min.js"></script>

    <script>
        $(document).ready(function() {
            var table = $('#permintaanTable').DataTable({
                responsive: true,
                autoWidth: false,
                pageLength: 10,
                lengthMenu: [5, 10, 25, 50, 100],
                language: {
                    url: "//cdn.datatables.net/plug-ins/1.13.6/i18n/id.json"
                }
            });

            // search input custom
            $('#searchInput').on('keyup', function() {
                table.search(this.value).draw();
            });

            // filter jenis permintaan (optional kalau ada dropdown filter)
            $('#jenisFilter').on('change', function() {
                var val = this.value;
                if (val) {
                    table.column(4).search(val, true, false).draw();
                } else {
                    table.column(4).search('').draw();
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('roles.Layout.partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\internal\resources\views/roles/admin/admin.blade.php ENDPATH**/ ?>