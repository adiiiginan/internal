@extends('roles.Layout.partials.app')
@section('title', 'Superadmin')
@section('content')
    @include('roles.superadmin.dashboard')
@endsection
